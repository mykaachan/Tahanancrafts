from django.urls import path, include
from.views import (UploadPaymentProofView,
                    MyOrdersView, 
                    CancelOrderView, 
                    ConfirmReceivedView, 
                    UploadPaymentProofView, 
                    VerifyPaymentView,
                    ArtisanOrdersView,
                    GetOrderForBookingView
                )

urlpatterns = [
    path("payment/upload-proof/", UploadPaymentProofView.as_view(), name="upload-payment-proof"),
    path("my-orders/", MyOrdersView.as_view(), name="my-orders"),
    path("cancel/", CancelOrderView.as_view(), name="order-cancel"),
    path("confirm-received/", ConfirmReceivedView.as_view(), name="order-confirm-received"),
    path('verify-payment/', VerifyPaymentView.as_view(), name="verify-payment"),
    path("artisan/orders-view/<int:artisan_id>/", ArtisanOrdersView.as_view()),
    path("get-order/<int:order_id>/", GetOrderForBookingView.as_view()),
]


